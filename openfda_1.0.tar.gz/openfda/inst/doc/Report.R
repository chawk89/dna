## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----example polyscore--------------------------------------------------------
#polyScore(dnaFile, top_SNPs)


## ----example------------------------------------------------------------------
#manhattan_plot(top_SNPs, pTrait = "Extraversion")


