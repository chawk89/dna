# openfda

Repository for openfda project by Alex Kern and Colby Hawker. Your R package name will be `openfda`.