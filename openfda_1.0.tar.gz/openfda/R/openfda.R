#' OpenFDA
#'
#' OpenFDA is a package to help users generate and explore polygenic scores for specific traits from DNA samples. Users can upload lists of SNP’s correlated with specific traits, or use the ‘Big 5’ personality traits sample data (researched by 23andMe) provided by the package. Users can also generate sample DNA test sets.
#'
#' Most functions will require one or both of the following data frames with many of following columns:
#' * `dnaFile` is a dataframe or tibble representing a DNA file; includes `SNP` (chr),`Chr` (int),`Position` (int),`Alleles` (chr)
#' * `summary_stats_df` is a dataframe (GWAS Statistics) including a list of SNP's associated with personality traits. includes: `SNP` (chr),`alleles` (chr),`trait` (chr),`effect` (dbl), `pvalue` (dbl), `scaffold` (chr), and `position` (int)  
#'
#' Samples of each are included in the package, but it is very important the column names and types are the same (also specifically outline for each function's .rd document)
#' 
#'
#' The package provides a number of functions including:
#' * [`polyScore`][polyScore()] which calculate polygenic scores for each observation for each trait.
#' * [`polyGenerate`][get_permutation_polygenic_scores()] which generates sample polygenic scores modeled off of top SNP lists.
#'
#' The package also includes valuable data sets, including:
#'
#' * A sample DNA file upload [`dnaFile`]
#' * GWAS summary statistics with top SNP's assosiated with each of the Big 5 personality traits [`top_SNPs`]
#' * GWAS summary statistics with significant SNP's assosiated with each of the Big 5 personality traits [`sig_SNPs`]
#'
#' @seealso [polyScore][polyScore()]
#' @seealso [polyGenerate][get_permutation_polygenic_scores()]
#' @importFrom utils globalVariables
#' @docType package
#' @name openfda
NULL

utils::globalVariables(names = c("PC1",
                                 "PC2",
                                 "Cluster",
                                 "traits",
                                 "1",
                                 "2",
                                 "3",
                                 "relative_pos",
                                 "chromInt",
                                 "ultimatePos",
                                 "negative_log10p",
                                 "colChrom",
                                 "absolute_effect",
                                 "alleles.top",
                                 "alleles.dna",
                                 "genotype_column",
                                 "allele1",
                                 "SNP",
                                 "trait",
                                 "effect_multiplier",
                                 "pvalue",
                                 "alleles",
                                 "freq.b",
                                 "trait",
                                 "effect",
                                 ".",
                                 ":=",
                                 "Score",
                                 "Permutation",
                                 "b",
                                 "variable",
                                 "score",
                                 "cluster",
                                 "score_contribution",
                                 "scaffold",
                                 "position"
                                 ))

