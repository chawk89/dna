#' Significant SNP List
#'
#' GWAS Summary Statistics for most statistically significant SNP's associated with Big 5 personality traits.
#' Data provided by 23andMe.
#' Contains `SNP`, `scaffole`, `position`, `alleles`,`pvalue`, `effect`,`stderr`,`trait`,`freq.b`
#'
#' @docType data
#'
#' @usage data(sig_SNPs)
#'
#' @format An object of class \code{"cross"}; see \code{\link[qtl]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Nat Genet (2017) Genome-wide analyses for personality traits 49:152-156
#' (\href{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5278898/#SD1}{PubMed})
#'
#' @references See also:
#' @source \href{https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3785122/}{QTL Archive}
#'
#' @examples
#' data(sig_SNPs)
#' 
"sig_SNPs"

#LD Independent Variants from 23andMe research paper: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5278898/#SD1
#From https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3785122/