#' @title polyCluster
#' @name polyCluster
#' @description Use K-means clustering to segment samples into k groups. The output is a dataframe with a column depicting cluster membership.
#' A snakeplot is output with the mean polygenic of each cluster for each trait.
#'
#' 
#' @param data data frame with polygenic scores by trait (note: Remove any row or observation identifier and use this for `sample_id`` as need)
#' @param centers the number of centers to include in the kmeans clustering
#' @param sample_id the number of centers to include in the kmeans clustering
#' 
#' @export
#'
#' @importFrom stats kmeans prcomp
#' @importFrom ggplot2 ggplot geom_point geom_line
#' @importFrom tibble tibble
#' @importFrom dplyr group_by mutate select summarize rename
#' @importFrom stringr str_replace_all
#' @importFrom magrittr %>%
#' @importFrom ggrepel geom_label_repel
#' @importFrom reshape2 melt
#' 
#' @examples
#' Big5_polyScores <- get_permutation_polygenic_scores(top_SNPs,60)
#' polyCluster(Big5_polyScores[3:6],3)
#' @keywords cluster
#' 


#Use K-Means clustering and output a snake plot to identify differences---
polyCluster <- function(data, centers=3, sample_id = rep(1:nrow(data))){
  cl <- scale(data) %>%
    stats::kmeans(centers)
  #assign cluster ID to each observation
  membership <- cl$cluster
  
  #combine data set with the cluster membership of each observation
  clusters <- cbind(data,membership) %>%
    as_tibble()
  
  
  ##produce snakeplot with mean polgenic score of every cluster for each trait
  snake_plot_data <- t(cl$centers) %>%
    as.data.frame() %>%
    tibble::rownames_to_column("traits") %>%
    reshape2::melt(id.vars = "traits", value.name = "score") %>%
    rename(cluster = variable) %>%
    as_tibble
    
  snake_plot <- ggplot2::ggplot(data = snake_plot_data, aes(x = traits, y = score, color=cluster, group=cluster)) + 
    geom_line() +
    labs(x = "Traits", y= "Polygenic Score") 
 
   print(snake_plot)
    
   return(clusters)
  }

#' @name pcaCluster
#' @title pcaCluster
#' @description K-Means clustering for polygenic scores. Principle Component Analysis is used to identify the top two components and plot segments on coordinate plane.
#' @param data data frame with polygenic scores by trait (note: Remove any row or observation identifier and use this for `sample_id`` as need)
#' @param centers the number of centers to include in the kmeans clustering
#' @param sample_id the number of centers to include in the kmeans clustering
#' 
#' @importFrom stats kmeans prcomp
#' @importFrom ggplot2 ggplot geom_point geom_line
#' @importFrom tibble tibble
#' @importFrom dplyr group_by mutate select summarize rename
#' @importFrom stringr str_replace_all
#' @importFrom magrittr %>%
#' @importFrom ggrepel geom_label_repel
#' @importFrom reshape2 melt
#' 
#' @examples
#' Big5_polyScores <- get_permutation_polygenic_scores(top_SNPs,60)
#' pcaCluster(Big5_polyScores[3:6],3)
#' @export

#Use PCA after K-Means clustering to plot segments on coordinate plane---

pcaCluster <- function(data, centers=3, sample_id = rep(1:nrow(data))){
  cl <- scale(data) %>%
    stats::kmeans(centers)
  #assign cluster ID to each observation
  member <- cl$cluster
  
  clusters <- cbind(data,member) %>%
    transmute_if(is.factor, as.double) %>%
    as_tibble()
  
  print(clusters)
  
  #pca to get top two components for x and y axis
  pca <- prcomp(data, scale = TRUE)
  pca_df <- cbind(data.frame(pca$rotation),member) 
  
  
  pca_cluster_data <- as.data.frame(cbind(pca$x[,1:2],member,sample_id)) %>%
    transmute(PC1 = PC1, PC2 = PC2, Cluster = as.factor(member)) %>%
    as_tibble()
  
  print(pca_cluster_data)
  
  ##plot clusters labeling membership
  scatter_plot <- ggplot2::ggplot(pca_cluster_data, aes(x=PC1, y=PC2, color = Cluster)) +
    geom_point() +
    geom_label_repel(aes(label=sample_id),
                     box.padding = .15,
                     point.padding = 0.3,
                     segment.color = 'grey60')
  print(scatter_plot)
  
  return(pca_cluster_data)

}






