#'
#' @name polyPlots
#' @title polyPlots
#' @description Manhattan plot showing the negative log10(pvalue) of each SNP in order of their position along the genome.
#' Important: please note that the inputs must be in matrix form and the columns must include the same names and types as shown.
#' @aliases polyPlots
#'
#' @param summary_stats_df Dataframe (GWAS Statistics) including list of SNP's associated with personality traits. Must include the following: `SNP` (chr),`alleles` (chr),`trait` (chr),`effect` (dbl), `pvalue` (dbl), `scaffold` (chr), and `position` (int)  
#' @param pTrait personality trait to use for Manhattan plots
#' @export
#'
#' @import ggplot2
#' @import dplyr
#' @importFrom magrittr %>%
#' @importFrom gtools mixedsort
#' 
#' @examples 
#' manhattan_plot(top_SNPs, pTrait = "Agreeableness")
#'
#' @keywords manhattan plots



#Output: Manhattan plot showing the negative log10(pvalue) of each SNP in order of their position along the genome

manhattan_plot <- function(summary_stats_df, pTrait){
  
  plotting_df <- filter(summary_stats_df, trait == pTrait) %>%
    #converting p values to -log10(p) for visualization
    mutate(negative_log10p = -log10(pvalue)) %>%
    group_by(scaffold) %>%
    #getting the relative position of each SNP along the chromosome
    mutate(relative_pos = position/max(position)) %>%
    # getting the chromosome number as an integer to add to the relative positions
    mutate(chromInt = as.numeric(gsub("chr", "", scaffold))) %>%
    #getting the final position of each SNP along the x-axis
    mutate(ultimatePos = relative_pos+chromInt) %>%
    #generating a variable to have alternating colors for the chromosomes
    mutate(colChrom = as.factor(chromInt%%2))
           
           ggplot(data = plotting_df, aes(x= ultimatePos, y = negative_log10p, color = colChrom ))+ geom_point() + 
             ggtitle(paste(plotting_df$trait,' Top 10000 SNPs')) +                                                              
             scale_x_continuous('Genomic Position', breaks = seq(1.5, 22.5, by=1), labels =gtools::mixedsort(unique(as.character(plotting_df$chromInt)))) +
             theme(axis.text.x = element_text(color = "black", size = 10, angle = 45), plot.title = element_text(face = "bold", hjust= 0.5), legend.position= 'none')
}

#' @name effect_size_plot
#' @title effect_size_plot
#' @description Uses DNA file upload to output is a Manhattan plot showing the negative log10(pvalue) of each SNP in order of their position along the genome.
#' 
#' @param summary_stats_df dataframe (GWAS Statistics) including list of SNP's associated with personality traits. Must include the following: `SNP` (chr),`alleles` (chr),`trait` (chr),`effect` (dbl), `pvalue` (dbl), `scaffold` (chr), and `position` (int)
#' @param pTrait personality trait to use for Manhattan plots
#' @param dnaFile dataframe or tibble representing a DNA file. Must include `SNP` (chr),`Chr` (int),`Position` (int),`Alleles` (chr)
#' @param absolute_value Boolean, default FALSE, with TRUE causing the absolute values of the effect sizes to be plotted, and false the actual values
#' @import ggplot2
#' @import dplyr
#' @importFrom magrittr %>%
#' @importFrom gtools mixedsort
#' 
#' @examples
#' effect_size_plot(top_SNPs, dnaFile, pTrait = "Extraversion")
#' 
#' @export




effect_size_plot <- function(summary_stats_df, dnaFile, pTrait, absolute_value = FALSE){
  

    plotting_df <- filter(summary_stats_df, trait == pTrait) %>%
    #getting the absolute values of the effect sizes in case we want to use them
    mutate(absolute_effect = abs(effect)) %>%
    group_by(scaffold) %>%
    #getting the relative position of each SNP along the chromosome
    mutate(relative_pos = position/max(position)) %>%
    # getting the chromosome number as an integer to add to the relative positions
    mutate(chromInt = as.numeric(gsub("chr", "", scaffold))) %>%
    #getting the final position of each SNP along the x-axis
    mutate(ultimatePos = relative_pos+chromInt) %>%
    #generating a variable to have alternating colors for the chromosomes
    mutate(colChrom =as.factor(chromInt%%2)) %>%
    #subsetting the SNPs to those in the dnaFile
    filter(SNP %in% dnaFile$SNP)
  
  #vector for passing into the ifelse statement determining whether the absolute effect sizes will be plotted
  absolute_value_vec = rep(absolute_value,nrow(plotting_df))  
  
  ggplot(data = plotting_df, aes(x= ultimatePos, y = ifelse(absolute_value_vec, absolute_effect,effect), color = colChrom )) +scale_color_manual(values=c("darkgreen","green")) +
    geom_point() +
    ggtitle(paste(plotting_df$trait,' Top 10000 SNP Effect Size')) +scale_x_continuous('Genomic Position', breaks = seq(1.5, length(unique(plotting_df$chromInt))+.5, by=1), labels= gtools::mixedsort(unique(as.character(plotting_df$chromInt))))+
    scale_y_continuous(ifelse(absolute_value, 'Effect Size Magnitude', 'Effect Size'))+
    theme(axis.text.x = element_text(color = "black", size = 12, angle = 45), plot.title = element_text(face = "bold", hjust= 0.5), legend.position= 'none')
}





