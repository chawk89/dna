#' @name polyScore 
#' @title polyScore 
#' @description Determine whether SNPs signficantly correlated with Big-5 Personality Traits are present in a DNA file.
#' Important: please note that the inputs must be in matrix form and the columns must include the same names and types as shown.
#' @param dnaFile matrix with one sample DNA file including `SNP` (chr),`Alleles` (chr)
#' @param summary_stats_df matrix including list of SNP's associated with personality traits. Must include the following: `SNP` (chr),`Alleles` (chr),`trait`, (chr),`effect` (dbl), `pvalue` (dbl) 
#' @export
#'
#' @importFrom tibble tibble
#' @importFrom dplyr group_by mutate select summarise rename
#' @importFrom stringr str_replace_all
#' @importFrom magrittr %>%
#' @importFrom knitr kable
#'
#' @examples
#' polyScore(dnaFile,top_SNPs)
#' 
#' @keywords score
#' 


#Scoring function to output trait associations-----


polyScore <- function(dnaFile,summary_stats_df){
  
  if (!(is.data.frame(dnaFile) || is.data.frame(summary_stats_df)))
    stop("Error, expecting data frames for both paramters")
  dnaFile_check <-  (typeof(dnaFile$SNP) == typeof(as.character(dnaFile$SNP)) & typeof(dnaFile$alleles) == typeof(as.character(dnaFile$alleles)))
  if (!all(dnaFile_check)) {
    stop("The DNA file must have a 'SNP' column <chr> and an 'alleles' column <chr> labeled as such")
  }
  
  score <- dplyr::inner_join(summary_stats_df,dnaFile, by = "SNP", suffix = c(".top", ".dna")) %>%
  #Splitting the alleles column into columns containing the reference and alternate SNP
  mutate(allele0 = substr(alleles.top, 1, 1), allele1 = substr(alleles.top, 2, 2), genotype_column = alleles.dna) %>%
  #Counting the number of instances of the alternate SNP to get the multiplier for the effect size
  mutate(effect_multiplier = stringr::str_count(genotype_column, allele1)) %>%
  #Calculating each SNPs' contribution to the polygenic score
  mutate(score_contribution = effect*effect_multiplier) %>%
  #Group by trait
  dplyr::group_by(trait) %>%
  #calculating the final polygenic score
  summarise(mean(score_contribution)) 
 
  #print a kable to the user for aesthetics
  print(knitr::kable(score))
  #variable returned will be a tibble
  invisible(score)

}

#' @name polyScore_effects
#' @title polyScore_effects
#' @description Output the SNP's detected in DNA file that have an effect on selected traits
#' @param dnaFile matrix with one sample DNA file including `SNP` (chr),`Alleles` (chr)
#' @param summary_stats_df matrix including list of SNP's associated with personality traits. Must include the following: `SNP` (chr),`Alleles` (chr),`trait`, (chr),`effect` (dbl), `pvalue` (dbl) 
#' @examples
#' polyScore_effects(dnaFile,sig_SNPs) 
#' @export
#' 


#Return all SNP's that have an effect---
polyScore_effects <- function(dnaFile,summary_stats_df){
  
  if (!(is.data.frame(dnaFile) || is.data.frame(summary_stats_df)))
    stop("Error, expecting data frames for both paramters")
  dnaFile_check <-  (typeof(dnaFile$SNP) == typeof(as.character(dnaFile$SNP)) & typeof(dnaFile$alleles) == typeof(as.character(dnaFile$alleles)))
  if (!all(dnaFile_check)) {
    stop("The DNA file must have a 'SNP' column <chr> and an 'alleles' column <chr> labeled as such")
  }
  
  effect <- dplyr::inner_join(summary_stats_df,dnaFile, by = "SNP", suffix = c(".top", ".dna")) %>%
  #Splitting the alleles column into columns containing the reference and alternate SNP
  mutate(allele0 = substr(alleles.top, 1, 1), allele1 = substr(alleles.top, 2, 2), genotype_column = alleles.dna) %>%
  #Counting the number of instances of the alternate SNP to get the multiplier for the effect size
  mutate(effect_multiplier = stringr::str_count(genotype_column, allele1)) %>%
  #Select features 
  select(SNP,trait,effect,effect_multiplier,pvalue) %>%
  #Filter out 0 effect_multipliers
  filter(effect_multiplier > 0)

  #print a kable to the user for aesthetics
  print(knitr::kable(effect))
  #variable returned will be a tibble
  invisible(effect)

}




