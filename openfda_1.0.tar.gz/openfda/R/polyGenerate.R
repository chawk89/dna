#' @title polyGenerate
#' @name polyGenerate
#' @description Generate your own example DNA data sets for testing purposes. This function permutes an uploaded DNA file and creates 'n' samples.
#' @aliases polyGenerate
#' 
#' @param summary_stats_df Dataframe (GWAS Statistics) including list of SNP's associated with personality traits. Must include the following: `SNP` (chr),`alleles` (chr),`trait` (chr),`effect` (dbl), `pvalue` (dbl), `scaffold` (chr), and `position` (int) , and `freq.b` (dbl)` 
#' @param number_of_permutations integer for the number of permuted genotypes to generate polygenic scores for.
#' 
#' @export
#'
#' @importFrom tibble tibble
#' @importFrom dplyr group_by mutate select summarize
#' @importFrom tidyr pivot_longer pivot_wider
#' @importFrom magrittr %>%
#' @importFrom stats rbinom var
#'
#' @examples
#' get_permutation_polygenic_scores(top_SNPs,60)
#' 
#' @keywords generate



#Generate----

get_permutation_polygenic_scores = function(summary_stats_df, number_of_permutations){
  dfs_merged = 0
  for (trait in summary_stats_df){
    trait_df_trimmed = summary_stats_df %>%
      #removing non-SNP variants 
      dplyr::filter(grepl('[ACGT]{2}', alleles)) %>%
      select(SNP, freq.b, trait, effect)
    #binding together all of the SNPs from the trait dataframes in trait_df_list
    if (dfs_merged==0){
      all_alleles_to_permute = trait_df_trimmed
    }
    else{
      all_alleles_to_permute = rbind(all_alleles_to_permute,trait_df_trimmed)
    }
    dfs_merged = dfs_merged+1
  }
  
  for (i in 1:number_of_permutations){    
    perm_name = paste("perm",i)
    
    #creating permutations of the B allele dosage by sampling from a binomial distribution with n = 2, p = the B allele frequency from the study population in the DF
    all_alleles_to_permute <-all_alleles_to_permute %>%
      mutate (!!as.symbol(perm_name) := rbinom(nrow(.), 2, freq.b))
  }
  
  #de_duplicated_permutations 
  de_duplicated_permutations = all_alleles_to_permute %>%
    group_by(SNP) %>%
    # for SNPs that appear for multiple traits, there are currently different permutations for each copy of the SNP, but we want the permutations to reflect individuals, so they can't have different genotypes at the same position. This will take the first permutation for a given SNP.
    slice(1) %>%
    ungroup() %>%
    select(SNP, starts_with('perm')) %>%
    inner_join(all_alleles_to_permute, by = c('SNP'), suffix = c('', '.remove_dups')) %>%
    # this removes the inconsistent permutations that were originally generated for those SNPs which overlap across traits
    select(-ends_with('.remove_dups')) %>%
    #getting the score contributions for each SNP
    mutate_at(vars(starts_with('perm')), c(score = ~.*effect)) %>%
    # the next two lines will get the polygenic scores for each trait
    group_by(trait) %>%
    # summarize and remove na's (example: agreeableness data set has NA values)
    summarize_at(vars(ends_with('score')), mean, na.rm = TRUE) %>%
    select(trait, ends_with('score')) %>%
    # the data at this point has dimensions n_traitsxn_permutations, which is very wide, so this creates row names out of the permutations and essentially transposes the data
    pivot_longer(cols = -c(trait), names_to=c('Permutation','remove'), values_to = 'Score', names_prefix = 'perm ', names_sep = '_') %>%
    select(-remove) %>%
    # now the data has  3 columns: trait, Permutation, and Score, but we would like to have separate columns for the scores for each trait for each permutation so that we can scale the scores for the same trait across the permutations, so this pivots the trait column out to create n_traits columns X n_permutations rows.
    pivot_wider(names_from = trait, values_from = Score, names_prefix = 'PR_Score_') %>%
    #generates Z scores for the polygenic risk scores
    mutate_at(vars(-c(Permutation)), scale)
  
  return(de_duplicated_permutations)
}





